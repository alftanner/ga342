#!/usr/bin/env bash
/hive/miners/custom/huishe/custom